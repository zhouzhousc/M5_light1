#ifndef _MAIN_H__
#define _MAIN_H__

struct config_type
{
  char stassid[32];
  char stapsw[32];
  char stapsn[64];
  char id[32];
  char key[32];
  char pwd[32];
  char logpwd[32];
  size_t pl;
  uint8_t magic;
};

void startTCPClient();
void doTCPClientTick();
void startUDPServer(int);
void doUdpServerTick();
void sendTCP(char *);
void sendUDP(char *);
void initParseData();
void parseTCPPackage(char*);
void parseUDPPackage(char*);
void parseUartPackage(char*);

void initHttpServer();
void doHttpServerTick();
void delayRestart(float);
void initMqttClient();
void linkMqttServer();
//void initGpio();
//void sendStateToMqtt();
void setmDns();

//常量
#define VER             "LightingM5_V1.0"
#define DEFAULT_APSSID  "LightingM5"
#define DEFAULT_STASSID ""
#define DEFAULT_STAPSW  ""
#define PINLED          2  //16是小板，大班是2
#define PINKEY          38
#define HOST_NAME       "Fii_Iot"
#define DEFAULT_PL      10 //默認頻率


//MQTT Server 配置
#define DEFAULT_ID    "10.129.7.199"                      //MQTT Server IP
#define DEFAULT_KEY    "iot"                              //MQTT User Name
#define DEFAULT_PWD    "iot123!"                          //MQTT User Name

const char apssid[]=DEFAULT_APSSID;

unsigned long lastWiFiCheckTick = 0;
bool ledState = 0;
bool debug = 0;
bool isOne = 1;//第一次启动需要设置设备地址
bool isWiFiErr = 1;

#include <M5Stack.h>
config_type config;
WiFiClient wclient;
PubSubClient client(wclient);
bool isConnMqttServer = 0;

String s = "";          //json頭 sn + dn
String mySn = ""; //设备SN设备信息
String ipMac = "";
String recoveryPassword = "fii"; //恢复出厂设置密码
long dispRssi = 0;
#endif
